import mongoose from "mongoose";

// Mongoose Schema
const schema = new mongoose.Schema({
    fullName: {
        type: String,
        required: true,
        trim: true
    },
    phone: {
        type: String,
        required: true,
        unique: true,  // Ensure phone numbers are unique
        trim: true
    },
    Service: {
        type: String,
        enum: ['premium', 'standard', 'professional'],
        required: true
    },
    description: {
        type: String,
        required: true,
        trim: true,
        minlength: 10,
        maxlength: 500
    },
    relation: {
        type: String,
        enum: ['sms', 'whatsapp', 'telegram'],
        required: true
    }
}, { timestamps: true });

export const model =mongoose.model('Contact',schema)