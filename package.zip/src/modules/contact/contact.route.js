import express from 'express';
import {createContact} from './contact.controller.js'
export const route = new express.Router()

route.post('/message',createContact)