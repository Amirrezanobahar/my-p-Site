import Joi from 'joi';

export const contactValidationSchema = Joi.object({
    fullName: Joi.string()
        .min(3)
        .max(50)
        .required()
        .messages({
            'string.empty': 'نام کامل نمی‌تواند خالی باشد',
            'string.min': 'نام کامل باید حداقل ۳ کاراکتر باشد',
            'string.max': 'نام کامل نمی‌تواند بیشتر از ۵۰ کاراکتر باشد',
            'any.required': 'نام کامل الزامی است'
        }),

    phone: Joi.string()
        .pattern(/^[0-9]{10,11}$/)
        .required()
        .messages({
            'string.pattern.base': 'شماره تلفن باید ۱۰ یا ۱۱ رقم باشد',
            'any.required': 'شماره تلفن الزامی است'
        }),

    Service: Joi.string()
        .valid('premium', 'standard', 'professional')
        .required()
        .messages({
            'any.only': 'سرویس باید یکی از مقادیر premium, standard یا professional باشد',
            'any.required': 'انتخاب سرویس الزامی است'
        }),

    description: Joi.string()
        .min(10)
        .max(500)
        .required()
        .messages({
            'string.min': 'توضیحات باید حداقل ۱۰ کاراکتر باشد',
            'string.max': 'توضیحات نمی‌تواند بیشتر از ۵۰۰ کاراکتر باشد',
            'any.required': 'توضیحات الزامی است'
        }),

    relation: Joi.string()
        .valid('sms', 'whatsapp', 'telegram')
        .required()
        .messages({
            'any.only': 'روش ارتباط باید یکی از مقادیر sms، whatsapp یا telegram باشد',
            'any.required': 'انتخاب روش ارتباط الزامی است'
        })
});

export const validateContact = (data) => {
    return contactValidationSchema.validate(data, { abortEarly: false });
};