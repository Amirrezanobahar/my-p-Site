import { contactValidationSchema } from "./contact.validator.js";
import nodemailer from 'nodemailer';

export const createContact = async (req, res) => {
    try {
        const { fullName, phone, Service, description, relation } = req.body;
        
        console.log('Received contact data:', req.body);
        

        // Validation
        const { error } = contactValidationSchema.validate(req.body, { abortEarly: false });
        
        if (error) {
            const errors = error.details.map(err => ({
                field: err.path[0],
                message: err.message
            }));
            return res.status(400).json({ errors });
        }

        const transporter = nodemailer.createTransport({
            service: 'gmail', // استفاده از سرویس Gmail
            auth: {
                user: 'nwbharamyrrda330@gmail.com', // ایمیل شما
                pass: 'xkeujfkrxqxetfke', // پسورد ایمیل شما
            },
        });
       

        // Email content
        const mailOptions = {
            from: `"Contact Form" <${process.env.EMAIL_USER}>`,
            to: process.env.CONTACT_RECEIVER_EMAIL, // receiver email address
            subject: 'New Contact Form Submission',
            html: `
                <h1>New Contact Request</h1>
                <p><strong>Full Name:</strong> ${fullName}</p>
                <p><strong>Phone:</strong> ${phone}</p>
                <p><strong>Service:</strong> ${Service}</p>
                <p><strong>Relation:</strong> ${relation}</p>
                <p><strong>Description:</strong></p>
                <p>${description}</p>
            `
        };

        // Send email
        await transporter.sendMail(mailOptions);

        return res.status(200).json({
            success: true,
            message: 'Contact form submitted successfully. We will get back to you soon!'
        });

    } catch (error) {
        console.error('Error in createContact:', error);
        return res.status(500).json({
            success: false,
            message: 'An error occurred while processing your request',
            error: error.message
        });
    }
}