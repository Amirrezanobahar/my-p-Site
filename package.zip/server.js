import mongoose from 'mongoose';
import { app } from "./src/app.js";
import dotenv from 'dotenv';

// Load environment variables
dotenv.config({ path: './src/.env' });



// Server startup with graceful shutdown
export const startServer = async () => {
  const server = app.listen(process.env.PORT || 3000, () => {
    console.log(`🚀 Server running on port ${process.env.PORT || 3000}`);
  });

  // Graceful shutdown
  const shutdown = (signal) => {
    console.log(`${signal} received. Shutting down gracefully...`);
    server.close(() => {
      console.log('💤 Server closed');
      process.exit(0);
    });
  };

  process.on('SIGTERM', () => shutdown('SIGTERM'));
  process.on('SIGINT', () => shutdown('SIGINT'));

  return server;
};

// Main startup function
const startBackend = async () => {
  try {
    await startServer();
  } catch (error) {
    console.error('🔥 Failed to start application:', error);
    process.exit(1);
  }
};

// Start the application
startBackend();